package com.al.project.Sysco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyscoApplicationTests {

	@Test
	void contextLoads() {
	}

}

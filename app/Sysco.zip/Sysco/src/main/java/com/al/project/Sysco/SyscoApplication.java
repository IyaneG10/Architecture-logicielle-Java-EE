package com.al.project.Sysco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyscoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SyscoApplication.class, args);
	}

}
